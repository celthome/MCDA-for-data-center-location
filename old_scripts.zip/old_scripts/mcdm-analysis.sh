#!/bin/bash

"""
Authors: Dominik Neumann, Celina Thomé
Execute this script inside the repo to execute the analysis. Exceptions to the workflow will be mentioned explicitely.
Keys for ohsome API and ors API are needed. Ideally ors API key with extended rate limit.
"""

# Data download from osm via ohsome API. Dowloaded data: 
# Power lines, power plants, telecom data, bodies of water, administrtive entities, nature reserves, protected areas, Grid (Ba-Wü), Centroids
python3	scripts download_data.ipynb 

# Data processing


# Accesibility analysis with ors


# Call the climate_to_centroids.py script
python3 scripts/climate_to_centroids.py

# Call the join_cent_hex.py script
python3 scripts/join_cent_hex.py

# Call the weighting.py script
python3 scripts/weighting.py

# install ohsome, geohexgrid, ors


administrative_boundaries_all; classified_power_plants; clipped_protected_area; powerlines_class_distance; telecom_points_class_distance; water; 